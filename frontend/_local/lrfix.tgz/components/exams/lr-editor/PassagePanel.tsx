import React from 'react';
import type { LrEditorState, LrPassageState } from '../../../lib/lr-editor/types.ts';
import { LET } from '../../../lib/lr-editor/constants.ts';
import ImageUploader from '../editor-shell/ImageUploader.tsx';
import { uploadSkillImage } from '../../../lib/exam-editor.ts';

export type PassagePanelProps = {
  ex: LrEditorState;
  activePassageIndex: number;
  onSelectPassage: (idx: number) => void;
  readOnly?: boolean;
  skillId?: string;
  onChangePassage: (updater: (draft: LrPassageState) => void) => void;
};

export default function PassagePanel({
  ex,
  activePassageIndex,
  onSelectPassage,
  readOnly = false,
  skillId,
  onChangePassage,
}: PassagePanelProps) {
  const passages = ex.passages || [];
  const currentPassage = passages[activePassageIndex] || {
    orderNo: activePassageIndex + 1,
    title: '',
    paras: ['', '', ''],
    audio: null,
    imgs: [],
    groups: [],
  };

  const paras = currentPassage.paras || [];
  const imgs = currentPassage.imgs || [];

  function updateTitle(title: string) {
    onChangePassage((p) => {
      p.title = title;
    });
  }

  function updatePara(idx: number, text: string) {
    onChangePassage((p) => {
      p.paras[idx] = text;
    });
  }

  function addPara() {
    onChangePassage((p) => {
      p.paras.push('');
    });
  }

  function removePara(idx: number) {
    if (paras.length <= 1) return;
    onChangePassage((p) => {
      p.paras.splice(idx, 1);
      // Update image attachments
      p.imgs.forEach((im) => {
        if (im.after >= idx) {
          im.after = Math.max(0, im.after - 1);
        }
      });
    });
  }

  function movePara(idx: number, delta: number) {
    onChangePassage((p) => {
      const target = idx + delta;
      if (target < 0 || target >= p.paras.length) return;
      const temp = p.paras[idx];
      p.paras[idx] = p.paras[target];
      p.paras[target] = temp;
    });
  }

  async function handleAddImage(file: File) {
    if (!skillId) {
      const url = URL.createObjectURL(file);
      const asset = { path: file.name, url, name: file.name };
      onChangePassage((p) => {
        p.imgs.push({ ...asset, after: 0 });
      });
      return asset;
    }
    const uploaded = await uploadSkillImage(skillId, file);
    const asset = { path: uploaded.path, url: uploaded.url, name: file.name };
    onChangePassage((p) => {
      p.imgs.push({ ...asset, after: 0 });
    });
    return asset;
  }

  function removeImage(imgIdx: number) {
    onChangePassage((p) => {
      p.imgs.splice(imgIdx, 1);
    });
  }

  return (
    <div className="flex flex-col h-full bg-[#FAF9F5] border-r border-solid border-[#E5E0D8]">
      {/* Passage Tabs */}
      <div className="px-4 pt-3 pb-2 border-b border-solid border-[#E5E0D8] bg-[#FAF9F5] shrink-0"><div className="inline-flex max-w-full items-center gap-1 p-[3px] rounded-xl bg-[#F3F0EA] overflow-x-auto">
        {passages.map((p, idx) => {
          const isActive = idx === activePassageIndex;
          const hasContent = (p.paras || []).some((x) => String(x || '').trim().length > 0);

          return (
            <button
              key={idx}
              type="button"
              onClick={() => onSelectPassage(idx)}
              className={`px-3.5 py-1.5 rounded-[9px] text-[14px] font-semibold transition-all shrink-0 flex items-center gap-2 ${
                isActive
                  ? 'bg-white border border-solid border-[#D6D4D0] text-[#352637] shadow-sm'
                  : 'border border-solid border-transparent text-[#706473] hover:text-[#352637]'
              }`}
            >
              <span>Passage {idx + 1}</span>
              {!hasContent && (
                <span className={`w-1.5 h-1.5 rounded-full bg-[#E5A800]`} />
              )}
            </button>
          );
        })}
      </div></div>

      {/* Passage Content Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Passage Title */}
        <div className="space-y-1 bg-white p-3.5 rounded-xl border border-[#E5E0D8] shadow-2xs">
          <label className="block text-[11px] font-bold text-[#706473] uppercase tracking-wider">
            Tiêu đề bài đọc (Passage {activePassageIndex + 1} Title)
          </label>
          <input
            type="text"
            value={currentPassage.title || ''}
            disabled={readOnly}
            onChange={(e) => updateTitle(e.target.value)}
            placeholder="Ví dụ: The History of Glass"
            className="w-full text-[15px] font-bold h-9 px-2.5 rounded-lg border border-[#D6D4D0] text-[#352637] placeholder-[#A89CA8] focus:outline-hidden focus:border-[#1F6A78]"
          />
        </div>

        {/* Paragraphs List */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[12px] font-bold text-[#4B3D4D]">
              Các đoạn văn ({paras.length} đoạn):
            </span>
            <span className="text-[11px] text-[#706473]">Tự động đánh nhãn A, B, C...</span>
          </div>

          {paras.map((text, idx) => {
            const label = LET[idx] || String(idx + 1);

            return (
              <div
                key={idx}
                className="bg-white p-3.5 rounded-xl border border-[#E5E0D8] shadow-2xs space-y-2.5 relative group"
              >
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-[#F3F0EA] text-[#352637] text-[13px] font-bold">
                    {label}
                  </span>

                  {!readOnly && (
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => movePara(idx, -1)}
                        disabled={idx === 0}
                        className="p-1 text-[#706473] hover:text-[#352637] disabled:opacity-30 rounded hover:bg-[#F3F0EA]"
                        title="Di chuyển lên"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                        </svg>
                      </button>
                      <button
                        type="button"
                        onClick={() => movePara(idx, 1)}
                        disabled={idx === paras.length - 1}
                        className="p-1 text-[#706473] hover:text-[#352637] disabled:opacity-30 rounded hover:bg-[#F3F0EA]"
                        title="Di chuyển xuống"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      </button>
                      {paras.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removePara(idx)}
                          className="p-1 text-[#C0412A] hover:bg-[#FDF3F0] rounded"
                          title="Xóa đoạn này"
                        >
                          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      )}
                    </div>
                  )}
                </div>

                <textarea
                  rows={4}
                  value={text}
                  disabled={readOnly}
                  onChange={(e) => updatePara(idx, e.target.value)}
                  placeholder={`Nhập nội dung cho đoạn ${label}...`}
                  className="w-full text-[13px] border border-[#D6D4D0] rounded-lg p-2.5 text-[#352637] placeholder-[#A89CA8] leading-relaxed focus:outline-hidden focus:border-[#1F6A78] resize-none"
                />
              </div>
            );
          })}

          {!readOnly && (
            <button
              type="button"
              onClick={addPara}
              className="w-full py-2 border-2 border-dashed border-[#D6D4D0] hover:border-[#1F6A78] text-[#1F6A78] text-[13px] font-semibold rounded-xl hover:bg-[#DFF1F4]/30 transition-all flex items-center justify-center gap-1.5"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Thêm đoạn văn mới (Đoạn {LET[paras.length] || String(paras.length + 1)})
            </button>
          )}
        </div>

        {/* Passage Images */}
        <div className="space-y-2 pt-2">
          <label className="block text-[12px] font-bold text-[#4B3D4D]">
            Hình ảnh minh họa trong bài đọc:
          </label>
          {imgs.map((im, idx) => (
            <div
              key={idx}
              className="bg-white p-3 rounded-xl border border-[#E5E0D8] shadow-2xs flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-2.5 truncate">
                <img
                  src={im.url || im.path || ''}
                  alt={im.name}
                  className="w-10 h-10 object-cover rounded-lg border border-[#E5E0D8]"
                />
                <div className="truncate">
                  <span className="text-[13px] font-medium text-[#352637] block truncate">
                    {im.name}
                  </span>
                  <span className="text-[11px] text-[#706473]">
                    {im.caption ? `Chú thích: ${im.caption}` : 'Hình minh họa bài đọc'}
                  </span>
                </div>
              </div>

              {!readOnly && (
                <button
                  type="button"
                  onClick={() => removeImage(idx)}
                  className="text-[#C0412A] hover:bg-[#FDF3F0] p-1.5 rounded text-[12px] font-semibold shrink-0"
                >
                  Xóa
                </button>
              )}
            </div>
          ))}

          {!readOnly && (
            <ImageUploader
              label="Tải ảnh minh họa cho bài đọc này"
              onUpload={handleAddImage}
              onRemove={() => {}}
              disabled={readOnly}
            />
          )}
        </div>
      </div>
    </div>
  );
}
