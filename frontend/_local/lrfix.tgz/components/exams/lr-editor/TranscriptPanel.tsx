import React from 'react';
import type { LrEditorState, LrPassageState } from '../../../lib/lr-editor/types.ts';

export type TranscriptPanelProps = {
  ex: LrEditorState;
  activePassageIndex: number;
  onSelectPassage: (idx: number) => void;
  readOnly?: boolean;
  onSeekAudio?: (sec: number) => void;
  onChangePassage: (updater: (draft: LrPassageState) => void) => void;
  onOpenTranscribeModal?: () => void;
};

function parseLine(raw: string): { timeTag: string; sec: number | null; text: string } {
  const match = raw.match(/^\s*\[(\d{1,2}):(\d{2})\]\s*(.*)$/);
  if (match) {
    const m = parseInt(match[1], 10);
    const s = parseInt(match[2], 10);
    return {
      timeTag: `[${match[1].padStart(2, '0')}:${match[2]}]`,
      sec: m * 60 + s,
      text: match[3],
    };
  }
  return { timeTag: '', sec: null, text: raw };
}

export default function TranscriptPanel({
  ex,
  activePassageIndex,
  onSelectPassage,
  readOnly = false,
  onSeekAudio,
  onChangePassage,
  onOpenTranscribeModal,
}: TranscriptPanelProps) {
  const passages = ex.passages || [];
  const currentPassage = passages[activePassageIndex] || {
    orderNo: activePassageIndex + 1,
    title: '',
    paras: [],
    audio: null,
    imgs: [],
    groups: [],
  };

  const paras = currentPassage.paras || [];

  function updateTitle(title: string) {
    onChangePassage((p) => {
      p.title = title;
    });
  }

  function updateLine(idx: number, fullLine: string) {
    onChangePassage((p) => {
      p.paras[idx] = fullLine;
    });
  }

  function addLine() {
    onChangePassage((p) => {
      p.paras.push('[00:00] SPEAKER: New dialogue...');
    });
  }

  function removeLine(idx: number) {
    onChangePassage((p) => {
      p.paras.splice(idx, 1);
    });
  }

  return (
    <div className="flex flex-col h-full bg-[#FAF9F7]">
      {/* Section Tabs */}
      <div className="px-4 pt-3 pb-2 border-b border-solid border-[#E5E0D8] bg-[#FAF9F5] shrink-0"><div className="inline-flex max-w-full items-center gap-1 p-[3px] rounded-xl bg-[#F3F0EA] overflow-x-auto">
        {passages.map((p, idx) => {
          const isActive = idx === activePassageIndex;
          const hasAudio = !!p.audio;
          const hasTranscript = (p.paras || []).some((x) => String(x || '').trim().length > 0);

          return (
            <button
              key={idx}
              type="button"
              onClick={() => onSelectPassage(idx)}
              className={`px-3.5 py-1.5 rounded-[9px] text-[14px] font-semibold transition-all shrink-0 flex items-center gap-2 ${
                isActive
                  ? 'bg-white border border-solid border-[#D6D4D0] text-[#352637] shadow-sm'
                  : 'border border-solid border-transparent text-[#706473] hover:text-[#352637]'
              }`}
            >
              <span>Section {idx + 1}</span>
              {(!hasAudio || !hasTranscript) && (
                <span className={`w-1.5 h-1.5 rounded-full bg-[#E5A800]`} />
              )}
            </button>
          );
        })}
      </div></div>

      {/* Transcript Header & Title */}
      <div className="p-4 space-y-3 flex-1 overflow-y-auto">
        <div className="space-y-1 bg-white p-3 rounded-xl border border-[#E5E0D8] shadow-2xs">
          <label className="block text-[11px] font-bold text-[#706473] uppercase tracking-wider">
            Tiêu đề phần nghe (Section {activePassageIndex + 1} Title)
          </label>
          <input
            type="text"
            value={currentPassage.title || ''}
            disabled={readOnly}
            onChange={(e) => updateTitle(e.target.value)}
            placeholder="Ví dụ: Booking a holiday cottage"
            className="w-full text-[15px] font-bold h-9 px-2.5 rounded-lg border border-[#D6D4D0] text-[#352637] placeholder-[#A89CA8] focus:outline-hidden focus:border-[#5E35B1]"
          />
        </div>

        {/* Toolbar: Speech-to-text AI & count */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <span className="text-[12px] font-bold text-[#4B3D4D]">
            Transcript ({paras.length} đoạn thoại):
          </span>

          {!readOnly && onOpenTranscribeModal && (
            <button
              type="button"
              onClick={onOpenTranscribeModal}
              className="inline-flex items-center gap-1.5 px-3 py-1 text-[12px] font-semibold bg-[#EDE7F6] text-[#5E35B1] hover:bg-[#D1C4E9] rounded-lg transition-colors"
            >
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 100-6 3 3 0 000 6z" />
              </svg>
              Tạo transcript từ ghi âm
            </button>
          )}
        </div>

        {/* Transcript lines */}
        <div className="space-y-2">
          {paras.map((rawLine, idx) => {
            const { timeTag, sec, text } = parseLine(rawLine);

            return (
              <div
                key={idx}
                className="bg-white p-2.5 rounded-xl border border-[#E5E0D8] shadow-2xs flex items-start gap-2 group"
              >
                {/* Timestamp chip */}
                {timeTag ? (
                  <button
                    type="button"
                    onClick={() => {
                      if (sec != null && onSeekAudio) onSeekAudio(sec);
                    }}
                    className="font-mono text-[11px] font-bold text-[#5E35B1] bg-[#EDE7F6] hover:bg-[#D1C4E9] px-2 py-1 rounded-md shrink-0 transition-colors"
                    title="Nhấp để phát từ mốc thời gian này"
                  >
                    {timeTag}
                  </button>
                ) : (
                  <span className="font-mono text-[11px] text-[#A89CA8] bg-[#F3F0EA] px-2 py-1 rounded-md shrink-0">
                    --:--
                  </span>
                )}

                <textarea
                  rows={2}
                  value={rawLine}
                  disabled={readOnly}
                  onChange={(e) => updateLine(idx, e.target.value)}
                  placeholder="[00:00] SPEAKER: Text..."
                  className="flex-1 text-[12px] font-sans border-0 p-0 text-[#352637] focus:ring-0 focus:outline-hidden leading-relaxed resize-none"
                />

                {!readOnly && (
                  <button
                    type="button"
                    onClick={() => removeLine(idx)}
                    className="text-[#A89CA8] hover:text-[#C0412A] font-bold text-[14px] p-1 shrink-0"
                    title="Xóa dòng này"
                  >
                    &times;
                  </button>
                )}
              </div>
            );
          })}

          {!readOnly && (
            <button
              type="button"
              onClick={addLine}
              className="w-full py-2 border-2 border-dashed border-[#D6D4D0] hover:border-[#5E35B1] text-[#5E35B1] text-[13px] font-semibold rounded-xl hover:bg-[#EDE7F6]/30 transition-all flex items-center justify-center gap-1.5"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Thêm dòng transcript
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
