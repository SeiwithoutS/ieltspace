import React, { useRef } from 'react';
import type { LrAsset, LrGroupState, LrPassageState } from '../../../../lib/lr-editor/types.ts';
import { limOf, overLimit, parseAlt } from '../../../../lib/lr-editor/pure.ts';
import { LIM } from '../../../../lib/lr-editor/constants.ts';
import ImageUploader from '../../editor-shell/ImageUploader.tsx';
import { uploadSkillImage } from '../../../../lib/exam-editor.ts';

export type CardProps = {
  group: LrGroupState;
  passage: LrPassageState;
  passageIndex: number;
  groupStartNum: number;
  readOnly?: boolean;
  skillId?: string;
  onChange: (updater: (draft: LrGroupState) => void) => void;
};

export default function DiagramCard({
  group,
  passage,
  groupStartNum,
  readOnly = false,
  skillId,
  onChange,
}: CardProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const marks = group.marks || [];
  const texts = group.texts || [];
  const ansList = group.ans || [];
  const altList = group.alt || [];
  const expList = group.exp || [];
  const li = limOf(group);

  const imgAsset: LrAsset | null =
    typeof group.img === 'string'
      ? { path: group.img, url: null, name: group.img.split('/').pop() || 'diagram.png' }
      : (group.img as LrAsset | null);

  async function handleImageUpload(file: File) {
    if (!skillId) {
      // Local preview if skillId not yet set
      const url = URL.createObjectURL(file);
      const asset = { path: file.name, url, name: file.name };
      onChange((g) => {
        g.img = asset;
      });
      return asset;
    }
    const uploaded = await uploadSkillImage(skillId, file);
    const asset = { path: uploaded.path, url: uploaded.url, name: file.name };
    onChange((g) => {
      g.img = asset;
    });
    return asset;
  }

  function handleImageRemove() {
    onChange((g) => {
      g.img = null;
    });
  }

  function handleImageClick(e: React.MouseEvent<HTMLDivElement>) {
    if (readOnly || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.round(((e.clientX - rect.left) / rect.width) * 100);
    const y = Math.round(((e.clientY - rect.top) / rect.height) * 100);

    onChange((g) => {
      if (!g.marks) g.marks = [];
      if (!g.texts) g.texts = [];
      if (!g.ans) g.ans = [];
      g.marks.push([x, y]);
      g.texts.push('');
      g.ans.push('');
    });
  }

  function updateMarkPos(idx: number, x: number, y: number) {
    onChange((g) => {
      if (!g.marks) return;
      g.marks[idx] = [x, y];
    });
  }

  function removeMark(idx: number) {
    onChange((g) => {
      if (!g.marks) return;
      g.marks.splice(idx, 1);
      g.texts?.splice(idx, 1);
      g.ans?.splice(idx, 1);
      g.alt?.splice(idx, 1);
      g.exp?.splice(idx, 1);
    });
  }

  function updateText(idx: number, val: string) {
    onChange((g) => {
      if (!g.texts) g.texts = [];
      g.texts[idx] = val;
    });
  }

  function updateAns(idx: number, val: string) {
    onChange((g) => {
      if (!g.ans) g.ans = [];
      g.ans[idx] = val;
    });
  }

  function updateAlt(idx: number, val: string) {
    onChange((g) => {
      if (!g.alt) g.alt = [];
      g.alt[idx] = val || null;
    });
  }

  function updateExp(idx: number, text: string, para: number | null) {
    onChange((g) => {
      if (!g.exp) g.exp = [];
      const current = g.exp[idx] || {};
      g.exp[idx] = { ...current, text, para };
    });
  }

  return (
    <div className="space-y-4">
      {/* Limit Selector */}
      <div className="flex items-center justify-between bg-[#FAF9F7] px-3.5 py-2.5 rounded-xl border border-[#E5E0D8]">
        <div className="flex items-center gap-2">
          <span className="text-[12px] font-semibold text-[#706473]">Giới hạn từ:</span>
          <select
            value={li >= 0 ? li : 2}
            disabled={readOnly}
            onChange={(e) => {
              const val = parseInt(e.target.value, 10);
              onChange((g) => {
                g.limit = val;
              });
            }}
            className="text-[12px] h-7 px-2 border border-[#D6D4D0] rounded-md text-[#352637] bg-white font-medium focus:outline-hidden"
          >
            {LIM.map((label, idx) => (
              <option key={idx} value={idx}>
                {label}
              </option>
            ))}
          </select>
        </div>

        <span className="text-[12px] text-[#706473]">
          Tổng số nhãn: <span className="font-semibold text-[#352637]">{marks.length}</span>
        </span>
      </div>

      {/* Image Uploader & Interactive Marking Canvas */}
      {!imgAsset?.url && !imgAsset?.path ? (
        <ImageUploader
          label="Tải lên sơ đồ / bản đồ (Diagram/Map Image)"
          onUpload={handleImageUpload}
          onRemove={handleImageRemove}
          disabled={readOnly}
        />
      ) : (
        <div className="space-y-2">
          <div className="flex items-center justify-between text-[12px]">
            <span className="font-semibold text-[#4B3D4D]">
              Nhấp trực tiếp lên hình để đặt điểm đánh dấu:
            </span>
            {!readOnly && (
              <button
                type="button"
                onClick={handleImageRemove}
                className="text-[#C0412A] hover:underline font-semibold"
              >
                Đổi hình ảnh khác
              </button>
            )}
          </div>

          <div
            ref={containerRef}
            onClick={handleImageClick}
            className="relative border border-[#D6D4D0] rounded-xl overflow-hidden bg-[#FAF9F7] select-none cursor-crosshair flex items-center justify-center p-2"
          >
            <img
              src={imgAsset.url || imgAsset.path || ''}
              alt={imgAsset.name}
              className="max-h-96 w-auto object-contain rounded-lg pointer-events-none"
            />

            {/* Markers */}
            {marks.map((m, idx) => {
              const qNum = groupStartNum + idx;
              const x = Array.isArray(m) ? m[0] : (m as { x: number }).x;
              const y = Array.isArray(m) ? m[1] : (m as { y: number }).y;

              return (
                <div
                  key={idx}
                  style={{ left: `${x}%`, top: `${y}%` }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 flex items-center justify-center w-7 h-7 rounded-full bg-[#1F6A78] text-white text-[12px] font-bold shadow-md border-2 border-white hover:scale-110 transition-transform cursor-pointer"
                  title={`Điểm ${qNum} (${x}%, ${y}%)`}
                  onClick={(e) => {
                    e.stopPropagation();
                  }}
                >
                  {qNum}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Labels List */}
      <div className="space-y-2.5 pt-1">
        <label className="block text-[12px] font-bold text-[#352637]">
          Danh sách nhãn và đáp án ({marks.length} câu hỏi):
        </label>

        {marks.map((m, idx) => {
          const qNum = groupStartNum + idx;
          const x = Array.isArray(m) ? m[0] : (m as { x: number }).x;
          const y = Array.isArray(m) ? m[1] : (m as { y: number }).y;
          const textVal = texts[idx] || '';
          const ansVal = ansList[idx] ?? '';
          const altVal = altList[idx] ?? '';
          const expVal = expList[idx] || {};
          const badAns = overLimit(ansVal, li);
          const alts = parseAlt(altVal);
          const badAlt = alts.some((a) => overLimit(a, li));

          return (
            <div
              key={idx}
              className="p-3 bg-white rounded-xl border border-[#E5E0D8] shadow-2xs space-y-2.5"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-[#F3F0EA] text-[#352637] text-[11px] font-bold shrink-0">
                    {qNum}
                  </span>
                  <span className="text-[12px] font-semibold text-[#352637]">
                    Vị trí: X={x}%, Y={y}%
                  </span>
                </div>

                {!readOnly && (
                  <button
                    type="button"
                    onClick={() => removeMark(idx)}
                    className="text-[#C0412A] hover:bg-[#FDF3F0] p-1 rounded font-bold text-[12px]"
                    title="Xóa điểm đánh dấu này"
                  >
                    &times; Xóa điểm
                  </button>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#706473] mb-0.5">
                  Mô tả / Nhãn hiển thị bên cạnh điểm
                </label>
                <input
                  type="text"
                  value={textVal}
                  disabled={readOnly}
                  onChange={(e) => updateText(idx, e.target.value)}
                  placeholder="Ví dụ: Sand, soda and lime are fed through a ___"
                  className="w-full text-[13px] h-8 px-2.5 rounded-lg border border-[#D6D4D0] text-[#352637] focus:outline-hidden focus:border-[#2963CC]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-[#706473] mb-0.5">
                    Đáp án chính
                  </label>
                  <input
                    type="text"
                    value={String(ansVal)}
                    disabled={readOnly}
                    onChange={(e) => updateAns(idx, e.target.value)}
                    placeholder="Đáp án chính xác"
                    className={`w-full text-[13px] h-8 px-2.5 rounded-lg border transition-colors ${
                      badAns
                        ? 'border-[#C0412A] bg-[#FDF3F0] text-[#C0412A]'
                        : 'border-[#D6D4D0] text-[#352637] focus:border-[#2963CC]'
                    }`}
                  />
                  {badAns && (
                    <span className="text-[10px] text-[#C0412A] mt-0.5 block">
                      Vượt giới hạn {LIM[li]}
                    </span>
                  )}
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#706473] mb-0.5">
                    Cách viết khác (cách nhau bởi dấu phẩy)
                  </label>
                  <input
                    type="text"
                    value={String(altVal)}
                    disabled={readOnly}
                    onChange={(e) => updateAlt(idx, e.target.value)}
                    placeholder="Ví dụ: 1500, tin"
                    className={`w-full text-[13px] h-8 px-2.5 rounded-lg border transition-colors ${
                      badAlt
                        ? 'border-[#C0412A] bg-[#FDF3F0] text-[#C0412A]'
                        : 'border-[#D6D4D0] text-[#352637] focus:border-[#2963CC]'
                    }`}
                  />
                </div>
              </div>

              {/* Explanation & Evidence */}
              <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-[#F3F0EA]">
                <select
                  value={expVal.para ?? ''}
                  disabled={readOnly}
                  onChange={(e) => {
                    const val = e.target.value === '' ? null : parseInt(e.target.value, 10);
                    updateExp(idx, expVal.text || expVal.note || '', val);
                  }}
                  className="text-[12px] h-7 px-2 border border-[#D6D4D0] rounded-md text-[#554756] bg-white focus:outline-hidden"
                >
                  <option value="">Bằng chứng: Không chọn đoạn</option>
                  {passage.paras.map((_, pIdx) => (
                    <option key={pIdx} value={pIdx}>
                      Đoạn {String.fromCharCode(65 + pIdx)}
                    </option>
                  ))}
                </select>

                <input
                  type="text"
                  value={expVal.text || expVal.note || ''}
                  disabled={readOnly}
                  onChange={(e) => updateExp(idx, e.target.value, expVal.para ?? null)}
                  placeholder="Ghi chú giải thích đáp án..."
                  className="flex-1 min-w-[180px] text-[12px] h-7 px-2 border border-[#D6D4D0] rounded-md text-[#554756] placeholder-[#A89CA8]"
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
